create view homepage as
  select `layc`.`personal_info`.`name`         AS `name`,
         `layc`.`personal_info`.`account`      AS `account`,
         `layc`.`personal_info`.`hoppy`        AS `hoppy`,
         `layc`.`personal_info`.`personal_sig` AS `personal_sig`,
         `layc`.`mood`.`mood_title`            AS `mood_title`,
         `layc`.`mood`.`mood_flag`             AS `mood_flag`,
         `layc`.`mood`.`mood_msg`              AS `mood_msg`,
         `layc`.`mood`.`mood_pic_url`          AS `mood_pic_url`
  from (`layc`.`personal_info` join `layc`.`mood` on ((`layc`.`mood`.`account` = `layc`.`personal_info`.`account`)))
  where (`layc`.`personal_info`.`account` = `layc`.`mood`.`account`);

